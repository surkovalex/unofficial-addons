# SPDX-License-Identifier: GPL-2.0
# Copyright (C) 2016-present Team LibreELEC (https://libreelec.tv)

import xbmcgui
import subprocess

xbmcgui.Dialog().ok('', 'This is a console-only addon')

